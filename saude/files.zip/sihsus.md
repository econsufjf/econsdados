# SIH-SUS — Sistema de Informações Hospitalares do SUS

## O que é

Registra as internações hospitalares **financiadas pelo SUS** (rede pública e privada conveniada), a partir da **AIH — Autorização de Internação Hospitalar**. Não cobre internações particulares ou por planos de saúde privados — isso é uma limitação de cobertura importante.

## Unidade de observação

Cada linha do arquivo (RD — Reduzida) é uma **internação (AIH aprovada)**, não um paciente. Um mesmo paciente pode ter múltiplas AIHs (reinternações, prorrogações, mudança de procedimento).

## Tipos de arquivo

| Arquivo | Conteúdo |
|---|---|
| **RD** (Reduzida) | Uma linha por AIH — o mais usado, resumo da internação |
| **RJ** (Rejeitada) | AIHs rejeitadas no processamento |
| **ER** (Rejeitada com erro) | Erros de processamento |
| **SP** (Serviços Profissionais) | Detalhamento de procedimentos/profissionais dentro da internação |
| **PA** | Produção ambulatorial vinculada (menos usado) |

Na prática, para a maioria das análises de morbidade/custo hospitalar, **RD já é suficiente**.

## Principais variáveis (arquivo RD)

**Identificação e localização**
- `MUNIC_RES` — município de residência do paciente
- `MUNIC_MOV` — município do estabelecimento (onde ocorreu a internação)
- `UF_ZI` — unidade da federação
- `CNES` — código do estabelecimento (permite cruzar com CNES para infraestrutura)

**Clínico**
- `DIAG_PRINC` — diagnóstico principal (CID-10)
- `DIAG_SECUN` — diagnóstico secundário
- `PROC_REA` — procedimento realizado
- `CAR_INT` — caráter da internação (eletiva vs. urgência)
- `MORTE` — óbito na internação (indicador direto de mortalidade hospitalar)

**Temporal**
- `DT_INTER` — data de internação
- `DT_SAIDA` — data de saída
- Permite calcular **tempo de permanência**

**Financeiro**
- `VAL_TOT` — valor total pago
- `VAL_UTI` — valor de UTI, se houver
- Componentes de valor por tipo de procedimento

**Demográfico**
- `IDADE`, `SEXO`, `COD_IDADE` (unidade da idade — dias/meses/anos, importante para neonatos)
- `RACA_COR`
- `INSTRU` — escolaridade (nem sempre bem preenchida)

**Perinatal**
- `NASC` — tipo de parto quando aplicável
- Não tem o mesmo detalhamento do SINASC, mas permite capturar **internações de recém-nascidos** e complicações neonatais via CID e procedimento

## Cuidados metodológicos

1. **Município de residência vs. de internação**: pacientes de cidades pequenas frequentemente se internam em polos regionais — isso gera viés se `MUNIC_MOV` for usado como proxy de "onde o evento ocorreu" quando na verdade se quer capturar exposição da população residente.

2. **AIH como unidade, não indivíduo**: sem identificador único de paciente confiável ao longo do tempo (antes de sistemas mais recentes), reinternações do mesmo indivíduo aparecem como observações independentes — cuidado com inferência causal que assuma independência.

3. **Não cobre rede privada não-SUS**: se o município tem forte presença de plano de saúde privado, a base subestima a morbidade real da população — problema de seletividade que pode correlacionar com renda/educação materna, algo sensível em desenhos tipo DiD.

4. **Mudanças de tabela de procedimentos (SIGTAP)**: códigos de procedimento mudam de nomenclatura periodicamente — comparações de longo prazo (ex: 2010 vs. 2023) exigem harmonização.

5. **Valor pago ≠ custo real**: `VAL_TOT` reflete tabela SUS de reembolso, não custo hospitalar efetivo — cuidado ao usar como proxy de severidade ou gravidade do caso.

6. **Subnotificação/atraso de processamento**: os últimos 2-3 meses disponíveis costumam estar incompletos por atraso de fechamento de competência — evitar usar o período mais recente sem checar.

## Acesso

- **TABNET**: bom para tabulações agregadas (nº de internações por causa/UF/ano)
- **FTP DataSUS** (`ftp://ftp.datasus.gov.br/dissemin/publicos/SIHSUS/`): microdados em formato `.dbc`, organizados por UF/ano/mês
- **PySUS** (Python): `from pysus.online_data import SIH` — importa e já descompacta o `.dbc`

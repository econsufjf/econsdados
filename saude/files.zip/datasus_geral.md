# DataSUS — Visão Geral

O **DataSUS** é o departamento de informática do SUS, vinculado à Secretaria Executiva do Ministério da Saúde. Sua função é coletar, processar e disponibilizar dados de saúde pública no Brasil através de diversos sistemas de informação, cada um com finalidade, unidade de observação e periodicidade próprias.

## Principais Bases de Dados

### 1. SIM — Sistema de Informações sobre Mortalidade
- Registra óbitos a partir da Declaração de Óbito (DO)
- Variáveis: causa básica (CID-10), local, idade, sexo, escolaridade da mãe (óbitos infantis), etc.
- Uso típico: mortalidade infantil, materna, por causas específicas

### 2. SINASC — Sistema de Informações sobre Nascidos Vivos
- Registra nascimentos a partir da Declaração de Nascido Vivo (DNV)
- Variáveis: peso ao nascer, Apgar, idade gestacional, tipo de parto, número de consultas pré-natal, escolaridade e idade da mãe
- Uso típico: desfechos neonatais, efeitos de choques na gestação

### 3. SIH-SUS — Sistema de Informações Hospitalares
- Registra internações pagas pelo SUS (via AIH — Autorização de Internação Hospitalar)
- Variáveis: diagnóstico (CID), procedimento, valor, tempo de permanência, município de residência x de internação
- Uso típico: morbidade hospitalar, demanda por leitos, custos
- *(Ver documento separado `sihsus.md` para detalhamento completo)*

### 4. SIA-SUS — Sistema de Informações Ambulatoriais
- Procedimentos ambulatoriais (consultas, exames, pequenas cirurgias)
- Uso típico: acesso à atenção primária/especializada

### 5. SINAN — Sistema de Informações de Agravos de Notificação
- Doenças e agravos de notificação compulsória (dengue, tuberculose, violência, etc.)
- Uso típico: vigilância epidemiológica

### 6. CNES — Cadastro Nacional de Estabelecimentos de Saúde
- Cadastro de todos os estabelecimentos de saúde (públicos e privados)
- Variáveis: infraestrutura, leitos, equipamentos, profissionais vinculados
- Uso típico: oferta de serviços de saúde, análises de acesso geográfico

### 7. e-SUS APS
- Substituiu o antigo SIAB; dados da Atenção Primária à Saúde
- Uso típico: cobertura de Estratégia Saúde da Família, atendimentos na APS

### 8. SISVAN — Sistema de Vigilância Alimentar e Nutricional
- Estado nutricional (peso, altura, IMC) de usuários acompanhados na APS

## Acesso aos Dados

| Ferramenta | Uso |
|---|---|
| **TABNET** | Tabulação online, pré-agregada, boa para estatísticas descritivas rápidas |
| **FTP DataSUS** | Microdados brutos (DBC/DBF), necessário para análises no nível do indivíduo |
| **PySUS / read.dbc (R)** | Pacotes para importar os microdados diretamente em Python/R |

## Observações Importantes para Pesquisa

- Mudanças de formulário/versão (ex: DNV, DO) ao longo do tempo podem quebrar comparabilidade — checar notas técnicas
- Municípios de residência vs. de ocorrência precisam ser tratados com cuidado (deslocamento para atendimento)
- Sub-notificação varia por região e período — relevante para dados mais antigos ou municípios pequenos
